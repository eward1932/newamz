<header id="nav-main" data-nav-language="fr_FR" class="nav-mobile nav-progressive-attribute nav-locale-fr nav-lang-fr nav-ssl nav-unrec nav-blueheaven">
    
    <div id="navbar" cel_widget_id="Navigation-mobile-navbar" role="navigation" class="nav-t-basicNoAuth nav-sprite-v3 celwidget" data-csa-c-id="81wxnr-adki0b-kjmy1w-ytldcr">
        <div id="nav-logobar">
            <div class="nav-left">
                
                
                
                <script type="text/javascript">window.navmet.tmp=+new Date();</script>
  <div id="nav-logo">
    <a href="#" id="nav-logo-sprites" class="nav-logo-link nav-progressive-attribute" aria-label="Amazon.fr">
      <span class="nav-sprite nav-logo-base" style="background-image: url(https://images-eu.ssl-images-amazon.com/images/G/08/gno/sprites/new-nav-sprite-global-1x_blueheaven-account._CB658093860_.png);
  background-repeat: no-repeat;
"></span>
      <span id="logo-ext" class="nav-sprite nav-logo-ext nav-progressive-content"></span>
     
    </a>
  </div>
<script type="text/javascript">window.navmet.push({key:'Logo',end:+new Date(),begin:window.navmet.tmp});</script>
            </div>
            <div class="nav-right">
                
                
                
                  
            </div>
        </div>
        

        
        
        <script type="text/javascript">var nav_t_after_searchbar = + new Date();</script>

        
        
        

        

        
        
        <!--NAVYAAN-SUBNAV-AND-SMILE-FROM-GURUPA-->
        
        
    </div>
    
    
    <div id="nav-progressive-subnav">
      
    </div>
</header>
